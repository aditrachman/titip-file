<?php require_once("auth.php"); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="sidebarcss/simple-sidebar.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </head>
    <body>

<div class="d-flex" id="wrapper">

  <!-- Sidebar -->
  <div class="bg-light border-right" id="sidebar-wrapper">
    <div class="sidebar-heading text-center">
    
                <div class="">
                    <div class="text-center">
                      <br>
                        <img class="img img-responsive rounded-circle mb-3" width="100" src="img/<?php echo $_SESSION['user']['photo'] ?>" />
                        
                        <h3><?php echo  $_SESSION["user"]["name"] ?></h3>
                        <p><?php echo $_SESSION["user"]["email"] ?></p>
    
                        <p><a href="logout.php">Logout</a></p>
                    </div>
                </div>
    
                
    </div>
    <div class="list-group list-group-flush">
      <a href="timeline.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
      <a href="timelinedaftar.php"  class="list-group-item list-group-item-action bg-light">Daftar</a>
      <a href="timelinelihat.php" class="list-group-item list-group-item-action bg-light">Lihat siswa</a>
    </div>
  </div>

  
  
  <div id="page-content-wrapper">

    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <h2><b>SMK CODER</b></h2>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Dropdown
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>

                    <!-- INI BATAS WRAPING DAFTAR -->
                    
    <div class="container-fluid">
      <h1 class="mt-4"><b>Daftar siswa</b></h1>
      <form action="proses.php" method="post">
                        
                        <div class="form-group">
                          <label>Nama</label>
                            <input type="text" name="nama" class="form-control" >
                        </div>
                        
                        <div class="form-group">
                        <label>Alamat</label>
                        <textarea name="alamat" id="" class="form-control"></textarea>
                        </div>
                       
                        <div class="form-group">
                          <label>Jenis Kelamin</label>
                           <select class="form-control" name="jenis_kelamin">
                              <option>-- Jenis kelamin --</option>
                              <option>Laki-Laki</option>
                              <option>Perempuan</option>
                           </select>
                         </div>  
                       
                          <div class="form-group">
                            <label>Agama</label>
                            <select class="form-control" name="agama">
                              <option>-- Agama --</option>
                              <option>Islam</option>
                              <option>Kristen</option>
                              <option>katolik</option>
                              <option>hindu</option>
                              <option>Buddha</option>
                              <option>Atheis</option>
                              <option>Tidak berotak</option>
                            </select>
                          </div>

                        <div class="form-group">
                          <label>Sekolah</label>
                            <input type="text" name="sekolah" class="form-control">
                        </div>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                    </form>




    <!-- Footer -->
<footer class="page-footer font-small unique-color-dark pt-4">

<!-- Footer Elements -->
<div class="container">

  <!-- Call to action -->
  <ul class="list-unstyled list-inline text-center py-2">
   <h3>SMK CODER</h3>
  </ul>
  <!-- Call to action -->

</div>
<!-- Footer Elements -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:Aditrachman23
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->
    


                    <!-- INI BATAS WRAPING DAFTAR -->

                    

    
    </div>
  </div>
  <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
function showCD(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","getcd.php?q="+str,true);
  xmlhttp.send();
}
</script>


</body>
</html>