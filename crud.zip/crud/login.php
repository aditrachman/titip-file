<?php 

require_once("config.php");

if(isset($_POST['login'])){

    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    $sql = "SELECT * FROM users WHERE username=:username OR email=:email";
    $stmt = $db->prepare($sql);
    
    // bind parameter ke query
    $params = array(
        ":username" => $username,
        ":email" => $username
    );

    $stmt->execute($params);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // jika user terdaftar
    if($user){
        // verifikasi password
        if(password_verify($password, $user["password"])){
            // buat Session
            session_start();
            $_SESSION["user"] = $user;
            // login sukses, alihkan ke halaman timeline
            header("Location: timeline.php");
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Login</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body>    
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand text-dark" href="#"><b>SMK CODER</b></a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li> <a href="index.php">Profile |</a> <a href="login.php"><span class="glyphicon glyphicon-user"></span>Login</a>
    <a href="register.php">  | Daftar <a href="table.php">  | lihat siswa</a></a>
    </ul>
  </div>
</nav>
  
  
  <div class="jumbotron text-center bg-light">
          <h1 id="waktu">LOGIN SISWA</h1>
      </div>
      <div class="container">
  
      <form action="" method="POST">
  
    <div class="form-group">
      <label for="username">Username</label>
      <input type="text" class="form-control" name="username">
    </div>
  
    <div class="mb-3">
      <label for="password">Sandi</label>
    <input type="text" class="form-control" name="password">
    </div>
  

    
  <button class="btn btn-outline-success" name="login" type="submit" >Login Siswa</button>
  
  </form>
  
  <!-- Footer -->
  <footer class="page-footer font-small unique-color-dark pt-4">
  
    <!-- Footer Elements -->
    <div class="container">
  
      <!-- Call to action -->
      <ul class="list-unstyled list-inline text-center py-2">
       <h3>SMK CODER</h3>
      </ul>
      <!-- Call to action -->
  
    </div>
    <!-- Footer Elements -->
  
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2020 Copyright:Aditrachman23
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->
    
</body>
</html>