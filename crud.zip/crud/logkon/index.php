<!DOCTYPE html>
<html lang="id">
<head>
    <title>Profile</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand text-dark" href="#"><b>SMK CODER</b></a>
    </div>
    <ul class="nav navbar-nav navbar-right">
      <li> <a href="index.php">Profile |</a> <a href="login.php"><span class="glyphicon glyphicon-user"></span>Login</a>
    <a href="register.php">  | Daftar</a>
    </ul>
  </div>
</nav>

<div class="jumbotron text-center bg-light">
        <h1 id="waktu">PROFILE SEKOLAH</h1>
        
    </div>



<div class="container text-center">
<img class="gambar container" src="943022.png" alt="">
<style>
  .gambar
{
    height: 300px;
    width: 510px;
}
</style>
</div>



<!-- Footer -->
<footer class="page-footer font-small unique-color-dark pt-4">

<!-- Footer Elements -->
<div class="container">

  <!-- Call to action -->
  <ul class="list-unstyled list-inline text-center py-2">
   <h3>SMK CODER</h3>
  </ul>
  <!-- Call to action -->

</div>
<!-- Footer Elements -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:Aditrachman23
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->
</body>
</html>