<?php require_once("auth.php"); ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pesbuk Timeline</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row">
        <div class="col-md-4">

            <div class="card">
                <div class="card-body text-center">

                    <img class="img img-responsive rounded-circle mb-3" width="160" src="img/<?php echo $_SESSION['user']['photo'] ?>" />
                    
                    <h3><?php echo  $_SESSION["user"]["name"] ?></h3>
                    <p><?php echo $_SESSION["user"]["email"] ?></p>

                    <p><a href="logout.php">Logout</a></p>
                </div>
            </div>

            
        </div>


        <div class="col-md-8">


            <form action="proses.php" method="post">

<div class="form-group">
  <label>Nama Siswa</label>
  <input type="text" class="form-control" name="nama">
</div>

<div class="mb-3">
  <label>Alamat</label>
  <textarea class="form-control" name="alamat"></textarea>
</div>

<div class="form-group">
  <label>Jenis Kelamin</label>
  <select class="form-control" name="jenis_kelamin">
    <option>-- Jenis kelamin --</option>
    <option>Laki-Laki</option>
    <option>Perempuan</option>
  </select>
</div>

<div class="form-group">
  <label>Agama</label>
  <select class="form-control" name="agama">
    <option>-- Agama --</option>
    <option>Islam</option>
    <option>Kristen</option>
    <option>katolik</option>
    <option>hindu</option>
    <option>Buddha</option>
    <option>Atheis</option>
    <option>Tidak berotak</option>
  </select>
</div>

<div class="form-group">
  <label>Asal Sekolah</label>
  <input type="text" class="form-control" name="sekolah">
</div>

<button class="btn btn-outline-success" type="submit">Daftar Siswa</button>

</form>
            
        </div>
    
    </div>
</div>

</body>
</html>