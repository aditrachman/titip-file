<?php

require_once("config.php");

if(isset($_POST['register'])){

    // filter data yang diinputkan
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    // enkripsi password
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);


    // menyiapkan query
    $sql = "INSERT INTO users (name, username, email, password) 
            VALUES (:name, :username, :email, :password)";
    $stmt = $db->prepare($sql);

    // bind parameter ke query
    $params = array(
        ":name" => $name,
        ":username" => $username,
        ":password" => $password,
        ":email" => $email
    );

    // eksekusi query untuk menyimpan ke database
    $saved = $stmt->execute($params);

    // jika query simpan berhasil, maka user sudah terdaftar
    // maka alihkan ke halaman login
    if($saved) header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>register</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body>
<nav class="navbar navbar-inverse">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand text-dark" href="#"><b>SMK CODER</b></a>
      </div>
      <ul class="nav navbar-nav navbar-right">
        <li> <a href="index.php">Profile |</a> <a href="login.php"><span class="glyphicon glyphicon-user"></span>Login</a>
      <a href="register.php">  | Daftar</a>
      </ul>
    </div>
  </nav>
  
  
  <div class="jumbotron text-center bg-light">
          <h1>DAFTAR AKUN SISWA</h1>
      </div>
      <div class="container">
  
      <form action="" method="post">
  
        <div class="form-group">
            <label for="name">Nama Lengkap</label>
            <input class="form-control" type="text" name="name" placeholder="Nama kamu" />
        </div>
    
        <div class="form-group">
            <label for="email">Email</label>
            <input class="form-control" type="email" name="email" placeholder="Alamat Email" />
        </div>

        <div class="form-group">
      <label for="username">Username</label>
      <input type="text" class="form-control" name="username">
    </div>
  
    <div class="mb-3">
      <label for="password">Sandi</label>
    <input type="text" class="form-control" name="password">
    </div>
  

    
  <button class="btn btn-outline-success" name="register" type="daftar" >Daftar Siswa</button>
  
  </form>
  
  <!-- Footer -->
  <footer class="page-footer font-small unique-color-dark pt-4">
  
    <!-- Footer Elements -->
    <div class="container">
  
      <!-- Call to action -->
      <ul class="list-unstyled list-inline text-center py-2">
       <h3>SMK CODER</h3>
      </ul>
      <!-- Call to action -->
  
    </div>
    <!-- Footer Elements -->
  
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2020 Copyright:Aditrachman23
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->




</body>
</html>