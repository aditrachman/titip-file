<?php require_once("auth.php"); ?>
<?php
include "koneksi.php";
$query = mysqli_query($koneksi, "select * from tb_23");
$jml = mysqli_num_rows($query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link href="sidebarcss/simple-sidebar.css" rel="stylesheet">
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </head>
    <body>

<div class="d-flex" id="wrapper">

  <!-- Sidebar -->
  <div class="bg-light border-right" id="sidebar-wrapper">
    <div class="sidebar-heading text-center">
    
                <div class="">
                    <div class="text-center">
                      <br>
                        <img class="img img-responsive rounded-circle mb-3" width="100" src="img/<?php echo $_SESSION['user']['photo'] ?>" />
                        
                        <h3><?php echo  $_SESSION["user"]["name"] ?></h3>
                        <p><?php echo $_SESSION["user"]["email"] ?></p>
    
                        <p><a href="logout.php">Logout</a></p>
                    </div>
                </div>
    
                
    </div>
    <div class="list-group list-group-flush">
      <a href="timeline.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
      <a href="timelinedaftar.php"  class="list-group-item list-group-item-action bg-light">Daftar</a>
      <a href="timelinelihat.php" class="list-group-item list-group-item-action bg-light">Lihat siswa</a>
    </div>
  </div>

  
  
  <div id="page-content-wrapper">

    <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <h2><b>SMK CODER</b></h2>

      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Link</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Dropdown
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </li>
        </ul>
      </div>
    </nav>

                            <!-- INI BATAS LIHAT-->
         <br>
                            <div class="container">
        <table class="table table-bordered">
            <tr>
                <thead class="thead-dark">
                <th>Nama</th>
                <th>Alamat</th>
                <th>Jenis kelamin</th>
                <th>Agama</th>
                <th>Sekolah</th>
                <th>aksi</th>
            </tr>
            </thead>
            <?php
            $c = 0;
            while ($row = mysqli_fetch_array($query)) {
                ?>
                <tr>
                    <td><?= $row['nama'] ?></td>
                    <td><?= $row['alamat']; ?></td>
                    <td><?= $row['jenis_kelamin']; ?></td>
                    <td><?= $row['agama']; ?></td>
                    <td><?= $row['sekolah']; ?></td>
                    <td>
                        <div class="">
                            <button data-toggle="tooltip" title="Edit <?= $row['nama']; ?>" data-id="<?= $row['id'] ?>" data-nama="<?= $row['nama']; ?>" data-alamat="<?= $row['alamat']; ?>" data-jenis_kelamin="<?= $row['jenis_kelamin']; ?>" data-agama="<?= $row['agama']; ?>" data-sekolah="<?= $row['sekolah']; ?>" class="editData btn btn-sm btn-warning">Edit</button>
                            <button data-toggle="tooltip" title="Hapus <?= $row['nama']; ?>" data-id="<?= $row['id'] ?>" data-nama="<?= $row['nama']; ?>" class="hapusData btn btn-sm btn-danger">Hapus</button>
                        </div>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table><br>
    </div>

                             <!-- Modal edit-->

    <div class="modal fade" id="edit-biodata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Biodata</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="simpan.php" method="post">
                        <input type="hidden" id="idedit" name="id">
                        <p>Nama Siswa</p>
                        <div class="form-group">
                            <input type="text" id="namaedit" name="nama" class="form-control" >
                        </div>
                        <p>Alamat</p>
                        <div class="form-group">
                        <textarea class="form-control" id="alamatedit" name="alamat"></textarea>
                        </div>
                        
                        <p>Jenis Kelamin</p>
                        <div class="form-group">
                        <select class="form-control" name="jenis_kelamin" id="jenis_kelaminedit" >
                            <option>-- Jenis kelamin --</option>
                            <option>Laki-Laki</option>
                            <option>Perempuan</option>
                        </select>
                        </div>
                        
                        <p>Agama</p>
                        <div class="form-group">
                            <input type="text" id="agamaedit" name="agama" class="form-control" >
                        </div>
                        <p>Asal Sekolah</p>
                        <div class="form-group">
                            <input type="text" id="sekolahedit" name="sekolah" class="form-control">
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
                             <!-- Modal edit-->


    <!-- Modal -->
    <div class="modal fade" id="hapus-biodata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Biodata</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p id="isinya"></p>
                </div>
                <div class="modal-footer">
                    <form action="delete.php" method="post">
                        <input type="hidden" name="id" id="idhapus">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('.tambahBiodata').click(function() {
            $('#tambah-biodata').modal('show');
        });

        $('.editData').click(function() {
            $('#idedit').val($(this).data('id'));
            $('#namaedit').val($(this).data('nama'));
            $('#alamatedit').val($(this).data('alamat'));
            $('#jenis_kelaminedit').val($(this).data('jenis_kelamin'));
            $('#agamaedit').val($(this).data('agama'));
            $('#sekolahedit').val($(this).data('sekolah'));
            $('#edit-biodata').modal('show');
        });

        $('.hapusData').click(function() {
            $('#idhapus').val($(this).data('id'));
            var nama = ($(this).data('nama'));
            $('#isinya').html('Apakah anda ingin menghapus <strong class="text-danger">' + nama + '</strong> ?');
            $('#hapus-biodata').modal('show');
        });
    </script>


                            <!-- INI BATAS LIHAT-->



    
    </div>
  </div>
  <!-- /#page-content-wrapper -->

</div>
<!-- /#wrapper -->

<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script>
function showCD(str) {
  if (str=="") {
    document.getElementById("txtHint").innerHTML="";
    return;
  }
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else {  // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","getcd.php?q="+str,true);
  xmlhttp.send();
}
</script>


</body>
</html>