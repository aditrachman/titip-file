<?php
$koneksi = mysqli_connect("localhost", "root", "", "db_adit");
if($koneksi){
	echo " ";
}else{
	echo"coba lagi";
}
